package client.oddc.fla.com.model;

import java.util.ArrayList;

/**
 * Created by yzharchuk on 8/10/2017.
 */

public class ContinuousDataCollection
{
    private ArrayList<ContinuousData> continuousData;

    public ArrayList<ContinuousData> getContinuousData()
    {
        return continuousData;
    }

    public void setContinuousData(ArrayList<ContinuousData> continuousData)
    {
        this.continuousData = continuousData;
    }
}
