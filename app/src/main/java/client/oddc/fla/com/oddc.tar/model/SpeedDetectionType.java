/**
 * Created by yzharchuk on 8/2/2017.
 */

package client.oddc.fla.com.model;

public enum SpeedDetectionType
{
    TYPE1,
    TYPE2
}